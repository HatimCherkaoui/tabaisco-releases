// content-ai.js — Auto-fill a pending search query into the AI chat prompt.
// Injected into Gemini, Mistral, and Copilot pages by the extension.
(function () {
    'use strict';

    // Per-host configuration: CSS selectors for the prompt input and send button.
    // Multiple selectors are separated by commas and tried in order.
    const HOST_CONFIG = {
        'gemini.google.com': {
            type:   'contenteditable',
            input:  'div.ql-editor[contenteditable="true"], rich-textarea .ql-editor, div[contenteditable="true"][data-placeholder]',
            submit: 'button[aria-label*="Send"], button[data-test-id="send-button"], button.send-button',
        },
        'chat.mistral.ai': {
            type:   'textarea',
            input:  'textarea',
            submit: 'button[data-testid="send-button"], button[aria-label*="Send"], button[type="submit"]',
        },
        'copilot.microsoft.com': {
            type:   'textarea',
            input:  'textarea#userInput, cib-text-input textarea, textarea[placeholder], div[contenteditable="true"]',
            submit: 'button[aria-label*="Submit"], button[aria-label*="Send"], cib-chat-main-container button[type="submit"]',
        },
    };

    const host = location.hostname;
    const cfg  = HOST_CONFIG[host];
    if (!cfg) return;

    chrome.storage.local.get(['pendingQuery'], ({ pendingQuery }) => {
        if (!pendingQuery) return;
        // Clear immediately so a page refresh doesn't re-trigger
        chrome.storage.local.remove('pendingQuery');
        waitForInput(cfg.input.split(',').map(s => s.trim()), el => {
            fillElement(el, cfg.type, pendingQuery);
            // Try to click the send button after a brief render tick
            setTimeout(() => {
                const sels = cfg.submit.split(',').map(s => s.trim());
                for (const s of sels) {
                    const btn = document.querySelector(s);
                    if (btn && !btn.disabled) { btn.click(); break; }
                }
            }, 400);
        });
    });

    // Poll + MutationObserver until the input element appears in the DOM
    function waitForInput(selectors, cb, timeout = 12000) {
        const find = () => {
            for (const s of selectors) {
                const el = document.querySelector(s);
                if (el) return el;
            }
            return null;
        };

        const found = find();
        if (found) { cb(found); return; }

        const deadline = Date.now() + timeout;
        const obs = new MutationObserver(() => {
            const el = find();
            if (el) { obs.disconnect(); cb(el); return; }
            if (Date.now() > deadline) obs.disconnect();
        });
        obs.observe(document.documentElement, { childList: true, subtree: true });
    }

    // Fill textarea or contenteditable, triggering framework-friendly change events
    function fillElement(el, type, text) {
        el.focus();
        if (type === 'contenteditable') {
            // Works for React-controlled and plain contenteditable divs
            document.execCommand('selectAll', false, null);
            document.execCommand('insertText', false, text);
        } else {
            // React overrides the native setter; use it to bypass the synthetic shim
            const desc = Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, 'value');
            if (desc && desc.set) {
                desc.set.call(el, text);
            } else {
                el.value = text;
            }
            el.dispatchEvent(new Event('input',  { bubbles: true }));
            el.dispatchEvent(new Event('change', { bubbles: true }));
        }
    }
})();
