// HubTab — background service worker (MV3)
// Minimal: no complex background logic needed.

chrome.runtime.onInstalled.addListener(({ reason }) => {
    if (reason === 'install') {
        chrome.storage.sync.set({
            defaultMode: 'google',
            newsApiKey: '',
            tempUnit: 'C'
        });
    }
});
